import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";
import toast from "react-hot-toast";
import useAuthStore from "../context/authStore";

export default function RegisterPage() {
  const navigate = useNavigate();
  const { register, isLoading } = useAuthStore();
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword)
      return toast.error("Passwords do not match");
    if (form.password.length < 6)
      return toast.error("Password must be at least 6 characters");
    const result = await register({
      name: form.name,
      email: form.email,
      password: form.password,
    });
    if (result.success) {
      toast.success("Account created! Check your email to verify.");
      navigate("/login");
    } else {
      toast.error(result.message || "Registration failed");
    }
  };

  const strength = (() => {
    const p = form.password;
    if (!p) return 0;
    let s = 0;
    if (p.length >= 6) s++;
    if (p.length >= 10) s++;
    if (/[A-Z]/.test(p)) s++;
    if (/[0-9]/.test(p)) s++;
    if (/[^A-Za-z0-9]/.test(p)) s++;
    return s;
  })();

  const strengthLabel = ["", "Weak", "Fair", "Good", "Strong", "Excellent"][
    strength
  ];
  const strengthColor = [
    "",
    "#ef4444",
    "#f59e0b",
    "#eab308",
    "#22c55e",
    "#00d4b4",
  ][strength];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&display=swap');

        .reg-page {
          min-height: 100vh;
          background: #08090d;
          display: flex;
          align-items: stretch;
          font-family: 'DM Sans', sans-serif;
          color: white;
        }

        .reg-side {
          width: 420px;
          flex-shrink: 0;
          background: #0d0f16;
          border-right: 1px solid rgba(255,255,255,0.06);
          padding: 3rem;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          position: relative;
          overflow: hidden;
        }

        .reg-side-orb {
          position: absolute;
          border-radius: 50%;
          filter: blur(70px);
          opacity: 0.15;
          pointer-events: none;
        }

        .reg-side-orb-1 {
          width: 350px; height: 350px;
          background: radial-gradient(circle, #a855f7, transparent);
          top: -80px; right: -80px;
        }

        .reg-side-orb-2 {
          width: 250px; height: 250px;
          background: radial-gradient(circle, #00d4b4, transparent);
          bottom: 80px; left: -50px;
        }

        .reg-side-brand {
          position: relative;
          z-index: 2;
          display: flex;
          align-items: center;
          gap: 10px;
          text-decoration: none;
        }

        .reg-logo {
          width: 36px; height: 36px;
          border-radius: 10px;
          background: linear-gradient(135deg, #00d4b4, #0099ff);
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .reg-diamond {
          width: 13px; height: 13px;
          background: #08090d;
          transform: rotate(45deg);
          border-radius: 2px;
        }

        .reg-brand-name {
          font-family: 'Syne', sans-serif;
          font-weight: 800;
          font-size: 1.2rem;
          letter-spacing: -0.02em;
          color: white;
        }

        .reg-side-mid {
          position: relative;
          z-index: 2;
        }

        .reg-benefits-title {
          font-family: 'Syne', sans-serif;
          font-size: 1.6rem;
          font-weight: 700;
          letter-spacing: -0.02em;
          margin-bottom: 1.5rem;
          line-height: 1.3;
        }

        .reg-benefit {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          margin-bottom: 1rem;
        }

        .benefit-dot {
          width: 22px; height: 22px;
          border-radius: 50%;
          background: rgba(0,212,180,0.12);
          border: 1px solid rgba(0,212,180,0.3);
          display: flex;
          align-items: center;
          justify-content: center;
          color: #00d4b4;
          font-size: 0.65rem;
          flex-shrink: 0;
          margin-top: 2px;
        }

        .benefit-text {
          font-size: 0.875rem;
          color: rgba(255,255,255,0.6);
          line-height: 1.5;
        }

        .benefit-text strong {
          color: rgba(255,255,255,0.9);
          font-weight: 600;
          display: block;
          margin-bottom: 2px;
        }

        .reg-side-bottom {
          position: relative;
          z-index: 2;
        }

        .reg-social-proof {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .avatars {
          display: flex;
        }

        .mini-av {
          width: 28px; height: 28px;
          border-radius: 50%;
          border: 2px solid #0d0f16;
          margin-left: -8px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 0.65rem;
          font-weight: 700;
        }

        .mini-av:first-child { margin-left: 0; }

        .sp-text {
          font-size: 0.8rem;
          color: rgba(255,255,255,0.4);
        }

        /* Main form area */
        .reg-main {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 3rem 2rem;
          overflow-y: auto;
        }

        .reg-form-wrap {
          width: 100%;
          max-width: 460px;
          animation: fadeUp 0.6s ease both;
        }

        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .reg-eyebrow {
          font-size: 0.75rem;
          font-weight: 600;
          color: #a855f7;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          margin-bottom: 0.75rem;
        }

        .reg-title {
          font-family: 'Syne', sans-serif;
          font-size: 2.2rem;
          font-weight: 800;
          letter-spacing: -0.03em;
          margin: 0 0 0.5rem;
        }

        .reg-sub {
          color: rgba(255,255,255,0.4);
          font-size: 0.9rem;
          margin-bottom: 2.5rem;
        }

        .reg-sub a {
          color: #00d4b4;
          text-decoration: none;
          font-weight: 500;
        }

        .reg-sub a:hover { text-decoration: underline; }

        .form-row {
          margin-bottom: 1.25rem;
        }

        .field-lbl {
          display: block;
          font-size: 0.8rem;
          font-weight: 600;
          color: rgba(255,255,255,0.5);
          letter-spacing: 0.06em;
          text-transform: uppercase;
          margin-bottom: 0.5rem;
        }

        .f-input-wrap { position: relative; }

        .f-input {
          width: 100%;
          padding: 12px 16px;
          border-radius: 10px;
          border: 1px solid rgba(255,255,255,0.08);
          background: rgba(255,255,255,0.04);
          color: white;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.9rem;
          outline: none;
          transition: all 0.2s ease;
        }

        .f-input::placeholder { color: rgba(255,255,255,0.18); }

        .f-input:focus {
          border-color: rgba(168,85,247,0.4);
          background: rgba(168,85,247,0.03);
          box-shadow: 0 0 0 3px rgba(168,85,247,0.06);
        }

        .f-input.pr { padding-right: 44px; }

        .eye-btn {
          position: absolute;
          right: 12px;
          top: 50%;
          transform: translateY(-50%);
          background: none;
          border: none;
          cursor: pointer;
          color: rgba(255,255,255,0.3);
          transition: color 0.2s;
          padding: 4px;
        }

        .eye-btn:hover { color: rgba(255,255,255,0.7); }

        .strength-bar {
          margin-top: 8px;
          display: flex;
          gap: 4px;
          align-items: center;
        }

        .strength-seg {
          height: 3px;
          flex: 1;
          border-radius: 2px;
          background: rgba(255,255,255,0.08);
          transition: background 0.3s;
        }

        .strength-label {
          font-size: 0.72rem;
          margin-left: 6px;
          font-weight: 600;
          flex-shrink: 0;
          min-width: 54px;
        }

        .reg-submit {
          width: 100%;
          padding: 13px 20px;
          border-radius: 10px;
          border: none;
          background: linear-gradient(135deg, #a855f7, #0099ff);
          color: white;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.95rem;
          font-weight: 700;
          cursor: pointer;
          letter-spacing: 0.02em;
          transition: all 0.25s ease;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          margin-top: 1.75rem;
          position: relative;
          overflow: hidden;
        }

        .reg-submit:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 12px 30px rgba(168,85,247,0.35);
        }

        .reg-submit:disabled { opacity: 0.6; cursor: not-allowed; }

        .reg-terms {
          text-align: center;
          font-size: 0.78rem;
          color: rgba(255,255,255,0.25);
          margin-top: 1rem;
          line-height: 1.6;
        }

        .reg-terms a {
          color: rgba(255,255,255,0.4);
          text-decoration: underline;
        }

        .spinner {
          width: 16px; height: 16px;
          border: 2px solid rgba(255,255,255,0.3);
          border-top-color: white;
          border-radius: 50%;
          animation: spin 0.7s linear infinite;
        }

        @keyframes spin { to { transform: rotate(360deg); } }

        @media (max-width: 900px) {
          .reg-side { display: none; }
        }
      `}</style>

      <div className="reg-page">
        {/* Side panel */}
        <div className="reg-side">
          <div className="reg-side-orb reg-side-orb-1" />
          <div className="reg-side-orb reg-side-orb-2" />

          <Link to="/" className="reg-side-brand">
            <div className="reg-logo">
              <div className="reg-diamond" />
            </div>
            <span className="reg-brand-name">ApexSaaS</span>
          </Link>

          <div className="reg-side-mid">
            <div className="reg-benefits-title">
              Everything your
              <br />
              team needs.
            </div>
            {[
              {
                title: "Free forever plan",
                desc: "All core features included with no time limit.",
              },
              {
                title: "14-day Pro trial",
                desc: "Full access to every feature, no card required.",
              },
              {
                title: "SOC2 Type II certified",
                desc: "Enterprise-grade security from day one.",
              },
              {
                title: "Dedicated onboarding",
                desc: "A real human helps you get set up fast.",
              },
            ].map((b) => (
              <div className="reg-benefit" key={b.title}>
                <div className="benefit-dot">✓</div>
                <div className="benefit-text">
                  <strong>{b.title}</strong>
                  {b.desc}
                </div>
              </div>
            ))}
          </div>

          <div className="reg-side-bottom">
            <div className="reg-social-proof">
              <div className="avatars">
                {[
                  {
                    bg: "linear-gradient(135deg,#00d4b4,#0099ff)",
                    letter: "A",
                  },
                  {
                    bg: "linear-gradient(135deg,#a855f7,#ec4899)",
                    letter: "M",
                  },
                  {
                    bg: "linear-gradient(135deg,#f59e0b,#ef4444)",
                    letter: "J",
                  },
                  {
                    bg: "linear-gradient(135deg,#22c55e,#0099ff)",
                    letter: "R",
                  },
                ].map(({ bg, letter }) => (
                  <div
                    className="mini-av"
                    key={letter}
                    style={{ background: bg }}
                  >
                    {letter}
                  </div>
                ))}
              </div>
              <span className="sp-text">40,000+ teams signed up</span>
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="reg-main">
          <div className="reg-form-wrap">
            <div className="reg-eyebrow">Create account</div>
            <h1 className="reg-title">Join ApexSaaS</h1>
            <p className="reg-sub">
              Already have an account? <Link to="/login">Sign in →</Link>
            </p>

            <form onSubmit={handleSubmit}>
              <div className="form-row">
                <label className="field-lbl">Full name</label>
                <input
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  required
                  placeholder="Your full name"
                  className="f-input"
                />
              </div>

              <div className="form-row">
                <label className="field-lbl">Email address</label>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  required
                  placeholder="you@example.com"
                  className="f-input"
                />
              </div>

              <div className="form-row">
                <label className="field-lbl">Password</label>
                <div className="f-input-wrap">
                  <input
                    type={showPassword ? "text" : "password"}
                    name="password"
                    value={form.password}
                    onChange={handleChange}
                    required
                    placeholder="••••••••"
                    className="f-input pr"
                    minLength="6"
                  />
                  <button
                    type="button"
                    className="eye-btn"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                {form.password && (
                  <div className="strength-bar">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <div
                        className="strength-seg"
                        key={i}
                        style={{
                          background: i <= strength ? strengthColor : undefined,
                        }}
                      />
                    ))}
                    <span
                      className="strength-label"
                      style={{ color: strengthColor }}
                    >
                      {strengthLabel}
                    </span>
                  </div>
                )}
              </div>

              <div className="form-row">
                <label className="field-lbl">Confirm password</label>
                <div className="f-input-wrap">
                  <input
                    type={showConfirm ? "text" : "password"}
                    name="confirmPassword"
                    value={form.confirmPassword}
                    onChange={handleChange}
                    required
                    placeholder="••••••••"
                    className="f-input pr"
                    minLength="6"
                  />
                  <button
                    type="button"
                    className="eye-btn"
                    onClick={() => setShowConfirm(!showConfirm)}
                  >
                    {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <button type="submit" disabled={isLoading} className="reg-submit">
                {isLoading ? (
                  <>
                    <div className="spinner" /> Creating account…
                  </>
                ) : (
                  "Create free account →"
                )}
              </button>

              <p className="reg-terms">
                By signing up you agree to our{" "}
                <Link to="#">Terms of Service</Link> and{" "}
                <Link to="#">Privacy Policy</Link>.
              </p>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}
