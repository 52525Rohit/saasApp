import React, { useEffect, useRef } from "react";
import { Link } from "react-router-dom";

export default function HomePage() {
  const heroRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.1 },
    );
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const features = [
    {
      tag: "01",
      title: "Instant Scale",
      desc: "Infrastructure that grows with you — from day one to day one million.",
      accent: "#00d4b4",
    },
    {
      tag: "02",
      title: "Zero-Trust Security",
      desc: "Military-grade encryption with audit trails for every action taken.",
      accent: "#0099ff",
    },
    {
      tag: "03",
      title: "Live Collaboration",
      desc: "Your team, synchronized in real time across any timezone.",
      accent: "#a855f7",
    },
    {
      tag: "04",
      title: "Transparent Pricing",
      desc: "No hidden fees. Pay for what you use. Cancel any day.",
      accent: "#f59e0b",
    },
  ];

  const stats = [
    { value: "40K+", label: "Active teams" },
    { value: "99.99%", label: "Uptime SLA" },
    { value: "$2.1B", label: "Revenue processed" },
    { value: "<40ms", label: "Global latency" },
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&display=swap');

        * { box-sizing: border-box; }

        .hp-root {
          min-height: 100vh;
          background: #08090d;
          color: white;
          font-family: 'DM Sans', sans-serif;
          overflow-x: hidden;
        }

        /* HERO */
        .hero {
          min-height: 100vh;
          display: flex;
          flex-direction: column;
          justify-content: center;
          position: relative;
          padding: 8rem 2rem 4rem;
          overflow: hidden;
        }

        .hero-bg {
          position: absolute;
          inset: 0;
          pointer-events: none;
        }

        .orb {
          position: absolute;
          border-radius: 50%;
          filter: blur(80px);
          opacity: 0.15;
        }

        .orb-1 {
          width: 600px; height: 600px;
          background: radial-gradient(circle, #00d4b4, transparent 70%);
          top: -100px; left: -100px;
          animation: drift 12s ease-in-out infinite;
        }

        .orb-2 {
          width: 500px; height: 500px;
          background: radial-gradient(circle, #0099ff, transparent 70%);
          bottom: -100px; right: -100px;
          animation: drift 15s ease-in-out infinite reverse;
        }

        .orb-3 {
          width: 300px; height: 300px;
          background: radial-gradient(circle, #a855f7, transparent 70%);
          top: 40%; left: 50%;
          animation: drift 10s ease-in-out infinite 3s;
          opacity: 0.08;
        }

        @keyframes drift {
          0%, 100% { transform: translate(0, 0); }
          33% { transform: translate(30px, -30px); }
          66% { transform: translate(-20px, 20px); }
        }

        /* Grid overlay */
        .hero-grid {
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px);
          background-size: 60px 60px;
          mask-image: radial-gradient(ellipse 80% 80% at 50% 50%, black 0%, transparent 100%);
        }

        .hero-content {
          max-width: 1100px;
          margin: 0 auto;
          position: relative;
          z-index: 2;
        }

        .hero-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 6px 14px;
          border-radius: 100px;
          border: 1px solid rgba(0, 212, 180, 0.3);
          background: rgba(0, 212, 180, 0.06);
          color: #00d4b4;
          font-size: 0.8rem;
          font-weight: 500;
          letter-spacing: 0.06em;
          text-transform: uppercase;
          margin-bottom: 2rem;
          animation: fadeUp 0.8s ease both;
        }

        .badge-dot {
          width: 6px; height: 6px;
          border-radius: 50%;
          background: #00d4b4;
          animation: pulse 2s ease-in-out infinite;
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.5; transform: scale(0.8); }
        }

        .hero-headline {
          font-family: 'Syne', sans-serif;
          font-size: clamp(3rem, 7vw, 6.5rem);
          font-weight: 800;
          line-height: 1.0;
          letter-spacing: -0.03em;
          margin: 0 0 1.5rem;
          animation: fadeUp 0.8s ease 0.1s both;
        }

        .hero-headline em {
          font-style: normal;
          background: linear-gradient(135deg, #00d4b4 0%, #0099ff 50%, #a855f7 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .hero-headline .muted {
          color: rgba(255,255,255,0.25);
        }

        .hero-sub {
          font-size: clamp(1rem, 2vw, 1.2rem);
          font-weight: 300;
          color: rgba(255,255,255,0.5);
          max-width: 560px;
          line-height: 1.7;
          margin-bottom: 3rem;
          animation: fadeUp 0.8s ease 0.2s both;
        }

        .hero-actions {
          display: flex;
          gap: 1rem;
          flex-wrap: wrap;
          animation: fadeUp 0.8s ease 0.3s both;
          margin-bottom: 5rem;
        }

        .cta-primary {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          padding: 14px 28px;
          border-radius: 12px;
          background: linear-gradient(135deg, #00d4b4, #0099ff);
          color: #08090d;
          font-weight: 700;
          font-size: 0.95rem;
          text-decoration: none;
          letter-spacing: 0.02em;
          transition: all 0.25s ease;
          position: relative;
          overflow: hidden;
        }

        .cta-primary::after {
          content: '';
          position: absolute;
          inset: 0;
          background: linear-gradient(135deg, rgba(255,255,255,0.25), transparent);
          opacity: 0;
          transition: opacity 0.2s;
        }

        .cta-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 16px 40px rgba(0,212,180,0.35);
        }

        .cta-primary:hover::after { opacity: 1; }

        .cta-secondary {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          padding: 14px 28px;
          border-radius: 12px;
          border: 1px solid rgba(255,255,255,0.12);
          color: rgba(255,255,255,0.7);
          font-weight: 500;
          font-size: 0.95rem;
          text-decoration: none;
          transition: all 0.25s ease;
          background: rgba(255,255,255,0.03);
        }

        .cta-secondary:hover {
          color: white;
          border-color: rgba(255,255,255,0.25);
          background: rgba(255,255,255,0.06);
        }

        .hero-trust {
          display: flex;
          gap: 2rem;
          flex-wrap: wrap;
          animation: fadeUp 0.8s ease 0.4s both;
        }

        .trust-item {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 0.85rem;
          color: rgba(255,255,255,0.4);
        }

        .trust-check {
          width: 18px; height: 18px;
          border-radius: 50%;
          background: rgba(0,212,180,0.15);
          border: 1px solid rgba(0,212,180,0.3);
          display: flex;
          align-items: center;
          justify-content: center;
          color: #00d4b4;
          font-size: 0.65rem;
          flex-shrink: 0;
        }

        /* STATS */
        .stats-strip {
          border-top: 1px solid rgba(255,255,255,0.06);
          border-bottom: 1px solid rgba(255,255,255,0.06);
          background: rgba(255,255,255,0.02);
          padding: 3rem 2rem;
        }

        .stats-inner {
          max-width: 1100px;
          margin: 0 auto;
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 2rem;
        }

        .stat-item {
          text-align: center;
        }

        .stat-value {
          font-family: 'Syne', sans-serif;
          font-size: clamp(2rem, 3.5vw, 3rem);
          font-weight: 800;
          letter-spacing: -0.03em;
          background: linear-gradient(135deg, white 0%, rgba(255,255,255,0.6) 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          margin-bottom: 0.3rem;
        }

        .stat-label {
          font-size: 0.8rem;
          color: rgba(255,255,255,0.35);
          text-transform: uppercase;
          letter-spacing: 0.08em;
          font-weight: 500;
        }

        /* FEATURES */
        .features-section {
          padding: 8rem 2rem;
          max-width: 1100px;
          margin: 0 auto;
        }

        .section-header {
          margin-bottom: 4rem;
        }

        .section-tag {
          font-size: 0.75rem;
          font-weight: 600;
          color: #00d4b4;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          margin-bottom: 1rem;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .section-tag::before {
          content: '';
          width: 24px;
          height: 1px;
          background: #00d4b4;
          display: block;
        }

        .section-title {
          font-family: 'Syne', sans-serif;
          font-size: clamp(2rem, 4vw, 3.5rem);
          font-weight: 800;
          letter-spacing: -0.03em;
          line-height: 1.1;
          margin: 0 0 1rem;
        }

        .features-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 1.5px;
          background: rgba(255,255,255,0.06);
          border-radius: 20px;
          overflow: hidden;
        }

        .feature-card {
          background: #0d0f16;
          padding: 3rem;
          position: relative;
          overflow: hidden;
          transition: background 0.3s ease;
          cursor: default;
        }

        .feature-card:hover {
          background: #111420;
        }

        .feature-card::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 1px;
          background: linear-gradient(90deg, transparent, var(--accent), transparent);
          opacity: 0;
          transition: opacity 0.3s;
        }

        .feature-card:hover::before { opacity: 1; }

        .feature-tag {
          font-family: 'Syne', sans-serif;
          font-size: 0.7rem;
          font-weight: 700;
          letter-spacing: 0.15em;
          color: var(--accent);
          margin-bottom: 1.5rem;
        }

        .feature-icon-box {
          width: 52px;
          height: 52px;
          border-radius: 14px;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 1.5rem;
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(255,255,255,0.06);
          font-size: 1.5rem;
          transition: all 0.3s;
        }

        .feature-card:hover .feature-icon-box {
          background: rgba(255,255,255,0.08);
          border-color: var(--accent);
          box-shadow: 0 0 20px rgba(0,212,180,0.1);
        }

        .feature-title {
          font-family: 'Syne', sans-serif;
          font-size: 1.4rem;
          font-weight: 700;
          letter-spacing: -0.02em;
          margin-bottom: 0.75rem;
          color: white;
        }

        .feature-desc {
          color: rgba(255,255,255,0.4);
          font-size: 0.9rem;
          line-height: 1.7;
          font-weight: 300;
        }

        /* CTA SECTION */
        .cta-section {
          padding: 6rem 2rem;
          margin: 0 2rem 4rem;
          border-radius: 24px;
          background: linear-gradient(135deg, rgba(0,212,180,0.08) 0%, rgba(0,153,255,0.08) 50%, rgba(168,85,247,0.08) 100%);
          border: 1px solid rgba(255,255,255,0.08);
          text-align: center;
          position: relative;
          overflow: hidden;
        }

        .cta-section::before {
          content: '';
          position: absolute;
          top: -50%;
          left: 50%;
          transform: translateX(-50%);
          width: 400px;
          height: 400px;
          background: radial-gradient(circle, rgba(0,212,180,0.1), transparent 70%);
          pointer-events: none;
        }

        .cta-title {
          font-family: 'Syne', sans-serif;
          font-size: clamp(2.5rem, 5vw, 4rem);
          font-weight: 800;
          letter-spacing: -0.03em;
          line-height: 1.1;
          margin-bottom: 1.5rem;
        }

        .cta-subtitle {
          color: rgba(255,255,255,0.45);
          font-size: 1.05rem;
          font-weight: 300;
          margin-bottom: 2.5rem;
          max-width: 480px;
          margin-left: auto;
          margin-right: auto;
        }

        /* Animations */
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(24px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .reveal {
          opacity: 0;
          transform: translateY(32px);
          transition: opacity 0.8s ease, transform 0.8s ease;
        }

        .reveal.visible {
          opacity: 1;
          transform: translateY(0);
        }

        @media (max-width: 768px) {
          .stats-inner { grid-template-columns: repeat(2, 1fr); }
          .features-grid { grid-template-columns: 1fr; }
          .cta-section { margin: 0 1rem 2rem; }
          .hero-trust { gap: 1rem; }
        }
      `}</style>

      <div className="hp-root">
        {/* HERO */}
        <section className="hero" ref={heroRef}>
          <div className="hero-bg">
            <div className="orb orb-1" />
            <div className="orb orb-2" />
            <div className="orb orb-3" />
            <div className="hero-grid" />
          </div>

          <div className="hero-content">
            <div className="hero-badge">
              <span className="badge-dot" />
              Now in public beta — version 2.0
            </div>

            <h1 className="hero-headline">
              The platform
              <br />
              <em>built for scale.</em>
              <br />
              <span className="muted">Nothing else.</span>
            </h1>

            <p className="hero-sub">
              Run your entire operation on one intelligent platform. Teams from
              seed to Series D trust ApexSaaS to power their most critical
              workflows.
            </p>

            <div className="hero-actions">
              <Link to="/register" className="cta-primary">
                Start for free
                <span>→</span>
              </Link>
              <Link to="/login" className="cta-secondary">
                Sign in
              </Link>
            </div>

            <div className="hero-trust">
              {[
                "No credit card required",
                "14-day free trial",
                "Cancel anytime",
              ].map((t) => (
                <div className="trust-item" key={t}>
                  <span className="trust-check">✓</span>
                  {t}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* STATS */}
        <div className="stats-strip reveal">
          <div className="stats-inner">
            {[
              { value: "40K+", label: "Active teams" },
              { value: "99.99%", label: "Uptime SLA" },
              { value: "$2.1B", label: "Revenue processed" },
              { value: "<40ms", label: "Global latency" },
            ].map((s) => (
              <div className="stat-item" key={s.label}>
                <div className="stat-value">{s.value}</div>
                <div className="stat-label">{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* FEATURES */}
        <section className="features-section">
          <div className="section-header reveal">
            <div className="section-tag">Why ApexSaaS</div>
            <h2 className="section-title">
              Engineered for
              <br />
              the demanding few.
            </h2>
          </div>

          <div className="features-grid reveal">
            {[
              {
                tag: "01",
                title: "Instant Scale",
                icon: "⚡",
                desc: "Infrastructure that grows with you — from day one to day one million. No ops headaches.",
                accent: "#00d4b4",
              },
              {
                tag: "02",
                title: "Zero-Trust Security",
                icon: "🛡",
                desc: "Military-grade encryption with complete audit trails for every action. SOC2 Type II certified.",
                accent: "#0099ff",
              },
              {
                tag: "03",
                title: "Live Collaboration",
                icon: "◎",
                desc: "Your team, synchronized in real time. Presence, comments, and version history built in.",
                accent: "#a855f7",
              },
              {
                tag: "04",
                title: "Transparent Pricing",
                icon: "◈",
                desc: "No hidden fees. No seat-based gotchas. Pay for what you use, nothing more.",
                accent: "#f59e0b",
              },
            ].map((f) => (
              <div
                className="feature-card"
                key={f.tag}
                style={{ "--accent": f.accent }}
              >
                <div className="feature-tag">{f.tag}</div>
                <div className="feature-icon-box">{f.icon}</div>
                <div className="feature-title">{f.title}</div>
                <div className="feature-desc">{f.desc}</div>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="cta-section reveal">
          <h2 className="cta-title">
            Ready to build
            <br />
            something great?
          </h2>
          <p className="cta-subtitle">
            Join thousands of teams already using ApexSaaS to move faster and
            operate smarter.
          </p>
          <Link
            to="/register"
            className="cta-primary"
            style={{ display: "inline-flex" }}
          >
            Start your free trial →
          </Link>
        </section>
      </div>
    </>
  );
}
