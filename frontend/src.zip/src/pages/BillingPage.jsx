import React, { useState } from "react";
import {
  CreditCard,
  Calendar,
  CheckCircle,
  XCircle,
  Download,
  TrendingUp,
} from "lucide-react";
import toast from "react-hot-toast";

export default function BillingPage() {
  const [subscription, setSubscription] = useState({
    status: "active",
    plan: "Pro",
    price: 29,
    nextBilling: "Jun 15, 2024",
    cardLast4: "4242",
  });

  const [invoices] = useState([
    { id: 1, date: "May 15, 2024", amount: 29, status: "paid" },
    { id: 2, date: "Apr 15, 2024", amount: 29, status: "paid" },
    { id: 3, date: "Mar 15, 2024", amount: 29, status: "paid" },
  ]);

  const plans = [
    {
      name: "Starter",
      price: 9,
      features: ["5 Projects", "1GB Storage", "Email Support"],
      accent: "#0099ff",
    },
    {
      name: "Pro",
      price: 29,
      features: [
        "Unlimited Projects",
        "50GB Storage",
        "Priority Support",
        "Advanced Analytics",
      ],
      active: true,
      accent: "#00d4b4",
    },
    {
      name: "Enterprise",
      price: 99,
      features: [
        "Custom Features",
        "Unlimited Storage",
        "24/7 Support",
        "Dedicated Account Manager",
      ],
      accent: "#a855f7",
    },
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');

        .bill-root {
          min-height: 100vh;
          background: #08090d;
          color: white;
          font-family: 'DM Sans', sans-serif;
          padding: 2.5rem;
        }

        .bill-header {
          max-width: 1100px;
          margin: 0 auto 3rem;
        }

        .bill-eyebrow {
          font-size: 0.72rem;
          font-weight: 600;
          color: #00d4b4;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          margin-bottom: 0.4rem;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .bill-eyebrow::before {
          content: '';
          width: 16px;
          height: 1px;
          background: #00d4b4;
        }

        .bill-title {
          font-family: 'Syne', sans-serif;
          font-size: clamp(1.8rem, 3vw, 2.8rem);
          font-weight: 800;
          letter-spacing: -0.03em;
          margin: 0 0 0.4rem;
        }

        .bill-sub {
          color: rgba(255,255,255,0.35);
          font-size: 0.9rem;
          font-weight: 300;
        }

        .bill-content {
          max-width: 1100px;
          margin: 0 auto;
          display: flex;
          flex-direction: column;
          gap: 1.5px;
          background: rgba(255,255,255,0.06);
          border-radius: 24px;
          overflow: hidden;
        }

        /* Current plan hero */
        .current-plan {
          background: #0d0f16;
          padding: 0;
          overflow: hidden;
        }

        .plan-hero {
          background: linear-gradient(135deg, #0d2b2a 0%, #0a1628 50%, #1a0d2b 100%);
          padding: 2.5rem;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 2rem;
          flex-wrap: wrap;
          position: relative;
          overflow: hidden;
          border-bottom: 1px solid rgba(255,255,255,0.06);
        }

        .plan-hero::before {
          content: '';
          position: absolute;
          top: -60px; right: -60px;
          width: 240px; height: 240px;
          background: radial-gradient(circle, rgba(0,212,180,0.15), transparent);
          pointer-events: none;
        }

        .plan-hero::after {
          content: '';
          position: absolute;
          bottom: -40px; left: 20%;
          width: 180px; height: 180px;
          background: radial-gradient(circle, rgba(0,153,255,0.1), transparent);
          pointer-events: none;
        }

        .plan-hero-left { position: relative; z-index: 1; }

        .plan-label {
          font-size: 0.72rem;
          font-weight: 600;
          color: rgba(0,212,180,0.7);
          letter-spacing: 0.1em;
          text-transform: uppercase;
          margin-bottom: 0.5rem;
        }

        .plan-name {
          font-family: 'Syne', sans-serif;
          font-size: 2.5rem;
          font-weight: 800;
          letter-spacing: -0.03em;
          margin-bottom: 0.25rem;
        }

        .plan-price {
          font-family: 'Syne', sans-serif;
          font-size: 1.5rem;
          font-weight: 700;
          color: rgba(255,255,255,0.5);
        }

        .plan-price strong { color: white; font-size: 2rem; }

        .plan-status-chip {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 6px 14px;
          border-radius: 100px;
          font-size: 0.8rem;
          font-weight: 600;
          background: rgba(34,197,94,0.12);
          border: 1px solid rgba(34,197,94,0.25);
          color: #22c55e;
          position: relative;
          z-index: 1;
        }

        .status-dot {
          width: 7px; height: 7px;
          border-radius: 50%;
          background: #22c55e;
          animation: blink 2s ease-in-out infinite;
        }

        @keyframes blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }

        .plan-meta {
          padding: 1.75rem 2.5rem;
          display: flex;
          align-items: center;
          gap: 2rem;
          flex-wrap: wrap;
          justify-content: space-between;
        }

        .plan-meta-item {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .meta-icon {
          width: 36px; height: 36px;
          border-radius: 10px;
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(255,255,255,0.07);
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .meta-key {
          font-size: 0.72rem;
          color: rgba(255,255,255,0.3);
          text-transform: uppercase;
          letter-spacing: 0.06em;
          font-weight: 600;
          margin-bottom: 2px;
        }

        .meta-val {
          font-size: 0.9rem;
          font-weight: 600;
          color: rgba(255,255,255,0.85);
        }

        .plan-actions {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }

        .btn-primary-small {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          border-radius: 9px;
          border: none;
          background: linear-gradient(135deg, #00d4b4, #0099ff);
          color: #08090d;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.825rem;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.25s ease;
        }

        .btn-primary-small:hover {
          transform: translateY(-1px);
          box-shadow: 0 8px 20px rgba(0,212,180,0.25);
        }

        .btn-ghost-small {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          border-radius: 9px;
          border: 1px solid rgba(255,255,255,0.1);
          background: rgba(255,255,255,0.03);
          color: rgba(255,255,255,0.6);
          font-family: 'DM Sans', sans-serif;
          font-size: 0.825rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .btn-ghost-small:hover {
          border-color: rgba(255,255,255,0.2);
          color: white;
          background: rgba(255,255,255,0.06);
        }

        .btn-danger-small {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          border-radius: 9px;
          border: 1px solid rgba(239,68,68,0.2);
          background: transparent;
          color: rgba(239,68,68,0.7);
          font-family: 'DM Sans', sans-serif;
          font-size: 0.825rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .btn-danger-small:hover {
          border-color: rgba(239,68,68,0.4);
          color: #ef4444;
          background: rgba(239,68,68,0.04);
        }

        /* Plans section */
        .section-wrap {
          background: #0d0f16;
          padding: 2.5rem;
        }

        .section-head {
          margin-bottom: 1.75rem;
        }

        .s-eyebrow {
          font-size: 0.72rem;
          font-weight: 600;
          color: #00d4b4;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          margin-bottom: 0.4rem;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .s-eyebrow::before {
          content: '';
          width: 14px;
          height: 1px;
          background: #00d4b4;
        }

        .s-title {
          font-family: 'Syne', sans-serif;
          font-size: 1.4rem;
          font-weight: 700;
          letter-spacing: -0.02em;
          margin: 0;
        }

        .plans-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
        }

        .plan-card {
          border-radius: 14px;
          border: 1px solid rgba(255,255,255,0.07);
          background: rgba(255,255,255,0.02);
          padding: 1.5rem;
          position: relative;
          transition: all 0.25s ease;
        }

        .plan-card.active {
          border-color: var(--accent);
          background: rgba(0,212,180,0.03);
          box-shadow: 0 0 0 1px var(--accent), 0 4px 24px rgba(0,212,180,0.08);
        }

        .plan-card:not(.active):hover {
          border-color: rgba(255,255,255,0.12);
          background: rgba(255,255,255,0.04);
        }

        .plan-card-current {
          position: absolute;
          top: 12px; right: 12px;
          font-size: 0.68rem;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: var(--accent);
          padding: 3px 9px;
          border-radius: 100px;
          border: 1px solid var(--accent);
          background: rgba(0,212,180,0.07);
        }

        .pc-name {
          font-family: 'Syne', sans-serif;
          font-size: 1rem;
          font-weight: 700;
          letter-spacing: -0.01em;
          margin-bottom: 0.5rem;
        }

        .pc-price {
          font-family: 'Syne', sans-serif;
          font-size: 1.8rem;
          font-weight: 800;
          letter-spacing: -0.03em;
          color: var(--accent);
          margin-bottom: 0.2rem;
        }

        .pc-period {
          font-size: 0.8rem;
          color: rgba(255,255,255,0.3);
          margin-bottom: 1.25rem;
        }

        .pc-features {
          list-style: none;
          padding: 0;
          margin: 0 0 1.25rem;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .pc-features li {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 0.82rem;
          color: rgba(255,255,255,0.55);
        }

        .pc-features li::before {
          content: '✓';
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: rgba(0,212,180,0.08);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 0.55rem;
          color: var(--accent);
          flex-shrink: 0;
          border: 1px solid rgba(0,212,180,0.2);
          line-height: 1;
          text-align: center;
        }

        .pc-btn {
          width: 100%;
          padding: 10px;
          border-radius: 9px;
          border: 1px solid rgba(255,255,255,0.08);
          background: rgba(255,255,255,0.03);
          color: rgba(255,255,255,0.5);
          font-family: 'DM Sans', sans-serif;
          font-size: 0.82rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }

        .pc-btn.active {
          background: rgba(0,212,180,0.08);
          border-color: rgba(0,212,180,0.25);
          color: #00d4b4;
          cursor: default;
        }

        .pc-btn:not(.active):hover {
          background: rgba(255,255,255,0.06);
          border-color: rgba(255,255,255,0.15);
          color: white;
        }

        /* Invoices */
        .invoice-list {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .invoice-item {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 14px 12px;
          border-radius: 10px;
          transition: background 0.2s;
          cursor: pointer;
        }

        .invoice-item:hover { background: rgba(255,255,255,0.03); }

        .invoice-badge {
          width: 38px; height: 38px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .invoice-id {
          font-size: 0.875rem;
          font-weight: 600;
          color: rgba(255,255,255,0.8);
          margin-bottom: 2px;
        }

        .invoice-date {
          font-size: 0.75rem;
          color: rgba(255,255,255,0.3);
        }

        .invoice-right {
          margin-left: auto;
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .invoice-amount {
          font-family: 'Syne', sans-serif;
          font-size: 1rem;
          font-weight: 700;
          color: white;
        }

        .dl-btn {
          width: 32px; height: 32px;
          border-radius: 8px;
          border: 1px solid rgba(255,255,255,0.07);
          background: rgba(255,255,255,0.03);
          color: rgba(255,255,255,0.3);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.2s;
        }

        .dl-btn:hover {
          background: rgba(0,212,180,0.08);
          border-color: rgba(0,212,180,0.25);
          color: #00d4b4;
        }

        /* Payment method */
        .payment-card {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 16px;
          border-radius: 12px;
          border: 1px solid rgba(255,255,255,0.07);
          background: rgba(255,255,255,0.02);
          margin-bottom: 10px;
          transition: all 0.2s;
        }

        .payment-card:hover {
          border-color: rgba(0,212,180,0.2);
          background: rgba(0,212,180,0.02);
        }

        .card-icon {
          width: 44px; height: 44px;
          border-radius: 12px;
          background: linear-gradient(135deg, #1a3a5c, #0d2040);
          border: 1px solid rgba(0,153,255,0.2);
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .card-info-name {
          font-size: 0.875rem;
          font-weight: 600;
          color: rgba(255,255,255,0.8);
          margin-bottom: 2px;
        }

        .card-info-exp {
          font-size: 0.75rem;
          color: rgba(255,255,255,0.3);
        }

        .card-actions {
          margin-left: auto;
          display: flex;
          gap: 6px;
        }

        .card-action-btn {
          padding: 6px 12px;
          border-radius: 7px;
          border: 1px solid rgba(255,255,255,0.07);
          background: transparent;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.78rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
          color: rgba(255,255,255,0.4);
        }

        .card-action-btn:hover {
          background: rgba(255,255,255,0.05);
          color: white;
        }

        .card-action-btn.danger { color: rgba(239,68,68,0.5); border-color: rgba(239,68,68,0.15); }
        .card-action-btn.danger:hover { background: rgba(239,68,68,0.04); color: #ef4444; }

        .add-card-btn {
          width: 100%;
          padding: 14px;
          border-radius: 12px;
          border: 1px dashed rgba(255,255,255,0.1);
          background: transparent;
          color: rgba(255,255,255,0.3);
          font-family: 'DM Sans', sans-serif;
          font-size: 0.875rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
        }

        .add-card-btn:hover {
          border-color: rgba(0,212,180,0.3);
          color: #00d4b4;
          background: rgba(0,212,180,0.02);
        }

        @media (max-width: 900px) {
          .bill-root { padding: 1.5rem; }
          .plans-grid { grid-template-columns: 1fr; }
          .plan-hero { flex-direction: column; align-items: flex-start; }
        }
      `}</style>

      <div className="bill-root">
        <div className="bill-header">
          <div className="bill-eyebrow">Billing</div>
          <h1 className="bill-title">Subscription & Billing</h1>
          <p className="bill-sub">Manage your plan and payment methods</p>
        </div>

        <div className="bill-content">
          {/* Current plan */}
          <div className="current-plan">
            <div className="plan-hero">
              <div className="plan-hero-left">
                <div className="plan-label">Current plan</div>
                <div className="plan-name">{subscription.plan}</div>
                <div className="plan-price">
                  <strong>${subscription.price}</strong>/month
                </div>
              </div>
              <div className={`plan-status-chip`}>
                <div className="status-dot" />
                {subscription.status === "active" ? "Active" : "Cancelled"}
              </div>
            </div>

            <div className="plan-meta">
              <div style={{ display: "flex", gap: "2rem", flexWrap: "wrap" }}>
                <div className="plan-meta-item">
                  <div className="meta-icon">
                    <Calendar size={15} color="rgba(255,255,255,0.5)" />
                  </div>
                  <div>
                    <div className="meta-key">Next billing</div>
                    <div className="meta-val">{subscription.nextBilling}</div>
                  </div>
                </div>
                <div className="plan-meta-item">
                  <div className="meta-icon">
                    <CreditCard size={15} color="rgba(255,255,255,0.5)" />
                  </div>
                  <div>
                    <div className="meta-key">Payment method</div>
                    <div className="meta-val">
                      •••• {subscription.cardLast4}
                    </div>
                  </div>
                </div>
              </div>

              <div className="plan-actions">
                <button className="btn-primary-small">
                  <TrendingUp size={14} /> Upgrade
                </button>
                <button className="btn-ghost-small">
                  <CreditCard size={14} /> Change card
                </button>
                {subscription.status === "active" && (
                  <button
                    className="btn-danger-small"
                    onClick={() => {
                      toast.success("Subscription cancelled");
                      setSubscription({ ...subscription, status: "cancelled" });
                    }}
                  >
                    Cancel
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Plans */}
          <div className="section-wrap">
            <div className="section-head">
              <div className="s-eyebrow">Plans</div>
              <h2 className="s-title">Choose your plan</h2>
            </div>
            <div className="plans-grid">
              {plans.map((plan) => (
                <div
                  className={`plan-card ${plan.active ? "active" : ""}`}
                  key={plan.name}
                  style={{ "--accent": plan.accent }}
                >
                  {plan.active && (
                    <div className="plan-card-current">Current</div>
                  )}
                  <div className="pc-name">{plan.name}</div>
                  <div className="pc-price">${plan.price}</div>
                  <div className="pc-period">per month</div>
                  <ul className="pc-features">
                    {plan.features.map((f) => (
                      <li key={f}>{f}</li>
                    ))}
                  </ul>
                  <button className={`pc-btn ${plan.active ? "active" : ""}`}>
                    {plan.active ? "Current plan" : "Switch plan"}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Invoices */}
          <div
            className="section-wrap"
            style={{ borderTop: "1.5px solid rgba(255,255,255,0.06)" }}
          >
            <div className="section-head">
              <div className="s-eyebrow">History</div>
              <h2 className="s-title">Billing history</h2>
            </div>
            <div className="invoice-list">
              {invoices.map((inv) => (
                <div className="invoice-item" key={inv.id}>
                  <div
                    className="invoice-badge"
                    style={{
                      background:
                        inv.status === "paid"
                          ? "rgba(34,197,94,0.08)"
                          : "rgba(239,68,68,0.08)",
                      border: `1px solid ${inv.status === "paid" ? "rgba(34,197,94,0.2)" : "rgba(239,68,68,0.2)"}`,
                    }}
                  >
                    {inv.status === "paid" ? (
                      <CheckCircle size={16} color="#22c55e" />
                    ) : (
                      <XCircle size={16} color="#ef4444" />
                    )}
                  </div>
                  <div>
                    <div className="invoice-id">
                      Invoice #{String(inv.id).padStart(4, "0")}
                    </div>
                    <div className="invoice-date">{inv.date}</div>
                  </div>
                  <div className="invoice-right">
                    <span className="invoice-amount">${inv.amount}</span>
                    <button
                      className="dl-btn"
                      onClick={() => toast.success("Invoice downloaded")}
                    >
                      <Download size={13} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Payment methods */}
          <div
            className="section-wrap"
            style={{ borderTop: "1.5px solid rgba(255,255,255,0.06)" }}
          >
            <div className="section-head">
              <div className="s-eyebrow">Payment</div>
              <h2 className="s-title">Payment methods</h2>
            </div>
            <div className="payment-card">
              <div className="card-icon">
                <CreditCard size={18} color="#0099ff" />
              </div>
              <div>
                <div className="card-info-name">
                  Visa ending in {subscription.cardLast4}
                </div>
                <div className="card-info-exp">Expires 12/25</div>
              </div>
              <div className="card-actions">
                <button className="card-action-btn">Edit</button>
                <button className="card-action-btn danger">Remove</button>
              </div>
            </div>
            <button className="add-card-btn">+ Add payment method</button>
          </div>
        </div>
      </div>
    </>
  );
}
