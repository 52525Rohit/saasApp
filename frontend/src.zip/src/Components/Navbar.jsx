import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { User, LogOut, Home, CreditCard, Menu, X } from "lucide-react";
import useAuthStore from "../context/authStore";

export default function Navbar() {
  const { isAuthenticated, user, logout } = useAuthStore();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLogout = () => {
    logout();
    navigate("/");
    setMobileMenuOpen(false);
  };

  const navLinks = [
    { to: "/dashboard", icon: Home, label: "Dashboard" },
    { to: "/profile", icon: User, label: "Profile" },
    { to: "/billing", icon: CreditCard, label: "Billing" },
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');

        .nav-root {
          position: sticky;
          top: 0;
          z-index: 100;
          font-family: 'DM Sans', sans-serif;
          transition: all 0.4s ease;
        }

        .nav-root.scrolled {
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          background: rgba(10, 12, 18, 0.92);
          border-bottom: 1px solid rgba(255,255,255,0.06);
          box-shadow: 0 4px 40px rgba(0,0,0,0.4);
        }

        .nav-root.top {
          background: transparent;
        }

        .nav-inner {
          max-width: 1280px;
          margin: 0 auto;
          padding: 0 2rem;
          display: flex;
          align-items: center;
          justify-content: space-between;
          height: 68px;
        }

        .nav-logo {
          display: flex;
          align-items: center;
          gap: 10px;
          text-decoration: none;
        }

        .logo-mark {
          width: 36px;
          height: 36px;
          background: linear-gradient(135deg, #00d4b4 0%, #0099ff 100%);
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          position: relative;
          overflow: hidden;
        }

        .logo-mark::before {
          content: '';
          position: absolute;
          inset: 0;
          background: linear-gradient(135deg, rgba(255,255,255,0.2) 0%, transparent 60%);
        }

        .logo-diamond {
          width: 14px;
          height: 14px;
          background: white;
          transform: rotate(45deg);
        }

        .logo-text {
          font-family: 'Syne', sans-serif;
          font-weight: 800;
          font-size: 1.25rem;
          letter-spacing: -0.02em;
          color: white;
        }

        .logo-text span {
          background: linear-gradient(90deg, #00d4b4, #0099ff);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .nav-links {
          display: flex;
          align-items: center;
          gap: 4px;
          list-style: none;
          margin: 0;
          padding: 0;
        }

        .nav-link {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 16px;
          border-radius: 8px;
          text-decoration: none;
          color: rgba(255,255,255,0.6);
          font-size: 0.875rem;
          font-weight: 500;
          letter-spacing: 0.01em;
          transition: all 0.2s ease;
          position: relative;
        }

        .nav-link:hover {
          color: white;
          background: rgba(255,255,255,0.06);
        }

        .nav-link svg {
          width: 16px;
          height: 16px;
          opacity: 0.7;
        }

        .nav-link:hover svg {
          opacity: 1;
        }

        .nav-divider {
          width: 1px;
          height: 20px;
          background: rgba(255,255,255,0.1);
          margin: 0 8px;
        }

        .btn-logout {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 16px;
          border-radius: 8px;
          background: none;
          border: none;
          cursor: pointer;
          color: rgba(255,255,255,0.5);
          font-family: 'DM Sans', sans-serif;
          font-size: 0.875rem;
          font-weight: 500;
          transition: all 0.2s ease;
        }

        .btn-logout:hover {
          color: #ff6b6b;
          background: rgba(255, 107, 107, 0.08);
        }

        .btn-login {
          padding: 8px 20px;
          border-radius: 8px;
          text-decoration: none;
          color: rgba(255,255,255,0.7);
          font-size: 0.875rem;
          font-weight: 500;
          transition: all 0.2s ease;
        }

        .btn-login:hover {
          color: white;
          background: rgba(255,255,255,0.06);
        }

        .btn-signup {
          padding: 9px 22px;
          border-radius: 8px;
          text-decoration: none;
          background: linear-gradient(135deg, #00d4b4, #0099ff);
          color: #0a0c12;
          font-size: 0.875rem;
          font-weight: 700;
          letter-spacing: 0.02em;
          transition: all 0.25s ease;
          position: relative;
          overflow: hidden;
        }

        .btn-signup::before {
          content: '';
          position: absolute;
          inset: 0;
          background: linear-gradient(135deg, rgba(255,255,255,0.2), transparent);
          opacity: 0;
          transition: opacity 0.2s;
        }

        .btn-signup:hover {
          transform: translateY(-1px);
          box-shadow: 0 8px 24px rgba(0, 212, 180, 0.35);
        }

        .btn-signup:hover::before { opacity: 1; }

        .mobile-btn {
          display: none;
          padding: 8px;
          background: none;
          border: none;
          cursor: pointer;
          color: rgba(255,255,255,0.7);
          border-radius: 8px;
          transition: all 0.2s;
        }

        .mobile-btn:hover {
          background: rgba(255,255,255,0.06);
          color: white;
        }

        .user-chip {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 6px 12px 6px 6px;
          background: rgba(255,255,255,0.05);
          border: 1px solid rgba(255,255,255,0.08);
          border-radius: 100px;
          margin-right: 4px;
        }

        .user-avatar {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: linear-gradient(135deg, #00d4b4, #0099ff);
          display: flex;
          align-items: center;
          justify-content: center;
          font-family: 'Syne', sans-serif;
          font-weight: 700;
          font-size: 0.75rem;
          color: #0a0c12;
        }

        .user-name {
          font-size: 0.8rem;
          font-weight: 500;
          color: rgba(255,255,255,0.8);
          max-width: 100px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        /* Mobile overlay */
        .mobile-overlay {
          display: none;
          position: fixed;
          inset: 0;
          top: 68px;
          background: rgba(10, 12, 18, 0.98);
          backdrop-filter: blur(20px);
          padding: 2rem;
          flex-direction: column;
          gap: 8px;
          border-top: 1px solid rgba(255,255,255,0.06);
          animation: slideDown 0.3s ease;
        }

        .mobile-overlay.open { display: flex; }

        @keyframes slideDown {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .mobile-nav-link {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px 16px;
          border-radius: 12px;
          text-decoration: none;
          color: rgba(255,255,255,0.7);
          font-size: 1rem;
          font-weight: 500;
          transition: all 0.2s;
          border: 1px solid transparent;
        }

        .mobile-nav-link:hover {
          color: white;
          background: rgba(255,255,255,0.05);
          border-color: rgba(255,255,255,0.08);
        }

        .mobile-divider {
          height: 1px;
          background: rgba(255,255,255,0.06);
          margin: 8px 0;
        }

        .mobile-logout {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px 16px;
          border-radius: 12px;
          background: none;
          border: 1px solid rgba(255,107,107,0.2);
          cursor: pointer;
          color: rgba(255,107,107,0.8);
          font-family: 'DM Sans', sans-serif;
          font-size: 1rem;
          font-weight: 500;
          transition: all 0.2s;
          text-align: left;
        }

        .mobile-logout:hover {
          color: #ff6b6b;
          background: rgba(255,107,107,0.06);
          border-color: rgba(255,107,107,0.4);
        }

        .mobile-signup {
          display: block;
          text-decoration: none;
          background: linear-gradient(135deg, #00d4b4, #0099ff);
          color: #0a0c12;
          padding: 14px 16px;
          border-radius: 12px;
          font-weight: 700;
          font-size: 1rem;
          text-align: center;
          margin-top: 8px;
        }

        @media (max-width: 768px) {
          .desktop-nav { display: none !important; }
          .mobile-btn { display: flex; }
        }

        @media (min-width: 769px) {
          .mobile-overlay { display: none !important; }
        }
      `}</style>

      <nav className={`nav-root ${scrolled ? "scrolled" : "top"}`}>
        <div className="nav-inner">
          {/* Logo */}
          <Link to="/" className="nav-logo">
            <div className="logo-mark">
              <div className="logo-diamond" />
            </div>
            <span className="logo-text">
              Apex<span>SaaS</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <div
            className="desktop-nav"
            style={{ display: "flex", alignItems: "center", gap: "4px" }}
          >
            {isAuthenticated ? (
              <>
                {user && (
                  <div className="user-chip">
                    <div className="user-avatar">
                      {(user.name || user.email || "U")[0].toUpperCase()}
                    </div>
                    <span className="user-name">{user.name || user.email}</span>
                  </div>
                )}
                {navLinks.map((link) => {
                  const Icon = link.icon;
                  return (
                    <Link key={link.to} to={link.to} className="nav-link">
                      <Icon />
                      {link.label}
                    </Link>
                  );
                })}
                <div className="nav-divider" />
                <button onClick={handleLogout} className="btn-logout">
                  <LogOut size={16} />
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn-login">
                  Login
                </Link>
                <Link to="/register" className="btn-signup">
                  Get Started →
                </Link>
              </>
            )}
          </div>

          {/* Mobile toggle */}
          <button
            className="mobile-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div className={`mobile-overlay ${mobileMenuOpen ? "open" : ""}`}>
        {isAuthenticated ? (
          <>
            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className="mobile-nav-link"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Icon size={18} />
                  {link.label}
                </Link>
              );
            })}
            <div className="mobile-divider" />
            <button onClick={handleLogout} className="mobile-logout">
              <LogOut size={18} />
              Sign out
            </button>
          </>
        ) : (
          <>
            <Link
              to="/login"
              className="mobile-nav-link"
              onClick={() => setMobileMenuOpen(false)}
            >
              Login
            </Link>
            <Link
              to="/register"
              className="mobile-signup"
              onClick={() => setMobileMenuOpen(false)}
            >
              Get Started Free →
            </Link>
          </>
        )}
      </div>
    </>
  );
}
