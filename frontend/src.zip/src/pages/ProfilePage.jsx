import React, { useState, useEffect } from "react";
import { Save, Shield, Lock, LogOut } from "lucide-react";
import toast from "react-hot-toast";
import useAuthStore from "../context/authStore";

export default function ProfilePage() {
  const { user, updateUser, isLoading } = useAuthStore();
  const [form, setForm] = useState({ name: "", email: "" });
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    if (user) setForm({ name: user.name || "", email: user.email || "" });
    setTimeout(() => setMounted(true), 50);
  }, [user]);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await updateUser(form);
    if (result?.success) toast.success("Profile updated");
    else toast.error("Failed to update profile");
  };

  if (!user)
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "#08090d",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div
          style={{
            width: 36,
            height: 36,
            border: "2px solid rgba(0,212,180,0.15)",
            borderTop: "2px solid #00d4b4",
            borderRadius: "50%",
            animation: "spin 0.8s linear infinite",
          }}
        />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');

        .prof-root {
          min-height: 100vh;
          background: #08090d;
          color: white;
          font-family: 'DM Sans', sans-serif;
          padding: 2.5rem;
        }

        .prof-layout {
          display: grid;
          grid-template-columns: 1fr 2fr;
          gap: 1.5px;
          background: rgba(255,255,255,0.06);
          border-radius: 24px;
          overflow: hidden;
          max-width: 1000px;
          margin: 0 auto;
          opacity: 0;
          transform: translateY(16px);
          transition: all 0.6s ease;
        }

        .prof-root.mounted .prof-layout { opacity: 1; transform: translateY(0); }

        .prof-sidebar {
          background: #0d0f16;
          padding: 3rem 2rem;
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          position: relative;
          overflow: hidden;
        }

        .prof-sidebar::before {
          content: '';
          position: absolute;
          top: -80px; left: 50%;
          transform: translateX(-50%);
          width: 200px; height: 200px;
          background: radial-gradient(circle, rgba(0,212,180,0.12), transparent);
          border-radius: 50%;
          filter: blur(30px);
        }

        .prof-avatar-wrap {
          position: relative;
          margin-bottom: 1.5rem;
        }

        .prof-avatar {
          width: 96px; height: 96px;
          border-radius: 24px;
          background: linear-gradient(135deg, #00d4b4, #0099ff);
          display: flex;
          align-items: center;
          justify-content: center;
          font-family: 'Syne', sans-serif;
          font-weight: 800;
          font-size: 2.5rem;
          color: #08090d;
          position: relative;
          z-index: 1;
        }

        .prof-avatar-ring {
          position: absolute;
          inset: -4px;
          border-radius: 28px;
          background: linear-gradient(135deg, #00d4b4, #0099ff);
          z-index: 0;
          opacity: 0.3;
        }

        .prof-user-name {
          font-family: 'Syne', sans-serif;
          font-size: 1.4rem;
          font-weight: 700;
          letter-spacing: -0.02em;
          margin-bottom: 4px;
        }

        .prof-user-email {
          font-size: 0.82rem;
          color: rgba(255,255,255,0.35);
          margin-bottom: 1.5rem;
          word-break: break-all;
        }

        .prof-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 5px 12px;
          border-radius: 100px;
          font-size: 0.75rem;
          font-weight: 600;
          margin-bottom: 2.5rem;
        }

        .prof-badge.verified {
          background: rgba(34,197,94,0.1);
          border: 1px solid rgba(34,197,94,0.25);
          color: #22c55e;
        }

        .prof-badge.pending {
          background: rgba(245,158,11,0.1);
          border: 1px solid rgba(245,158,11,0.25);
          color: #f59e0b;
        }

        .prof-meta {
          width: 100%;
          border-top: 1px solid rgba(255,255,255,0.06);
          padding-top: 1.5rem;
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .prof-meta-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 0.8rem;
        }

        .meta-key { color: rgba(255,255,255,0.3); }
        .meta-val { color: rgba(255,255,255,0.7); font-weight: 500; }

        /* Main form */
        .prof-main {
          background: #0d0f16;
          padding: 3rem;
        }

        .section-eyebrow {
          font-size: 0.72rem;
          font-weight: 600;
          color: #00d4b4;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          margin-bottom: 0.5rem;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .section-eyebrow::before {
          content: '';
          width: 16px;
          height: 1px;
          background: #00d4b4;
        }

        .section-title {
          font-family: 'Syne', sans-serif;
          font-size: 1.6rem;
          font-weight: 700;
          letter-spacing: -0.02em;
          margin: 0 0 2rem;
        }

        .form-divider {
          height: 1px;
          background: rgba(255,255,255,0.06);
          margin: 2rem 0;
        }

        .field {
          margin-bottom: 1.5rem;
        }

        .field-label {
          display: block;
          font-size: 0.75rem;
          font-weight: 600;
          color: rgba(255,255,255,0.4);
          letter-spacing: 0.08em;
          text-transform: uppercase;
          margin-bottom: 0.6rem;
        }

        .field-input {
          width: 100%;
          padding: 12px 16px;
          border-radius: 10px;
          border: 1px solid rgba(255,255,255,0.07);
          background: rgba(255,255,255,0.03);
          color: white;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.9rem;
          outline: none;
          transition: all 0.2s ease;
        }

        .field-input::placeholder { color: rgba(255,255,255,0.18); }

        .field-input:focus {
          border-color: rgba(0,212,180,0.35);
          background: rgba(0,212,180,0.03);
          box-shadow: 0 0 0 3px rgba(0,212,180,0.06);
        }

        .field-input:disabled {
          opacity: 0.4;
          cursor: not-allowed;
        }

        .field-hint {
          font-size: 0.76rem;
          color: rgba(255,255,255,0.25);
          margin-top: 6px;
        }

        .save-btn {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 11px 24px;
          border-radius: 10px;
          border: none;
          background: linear-gradient(135deg, #00d4b4, #0099ff);
          color: #08090d;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.875rem;
          font-weight: 700;
          cursor: pointer;
          letter-spacing: 0.02em;
          transition: all 0.25s ease;
        }

        .save-btn:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 8px 24px rgba(0,212,180,0.3);
        }

        .save-btn:disabled { opacity: 0.6; cursor: not-allowed; }

        /* Security section */
        .security-grid {
          display: flex;
          flex-direction: column;
          gap: 8px;
          margin-top: 2rem;
        }

        .sec-btn {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 14px 16px;
          border-radius: 12px;
          border: 1px solid rgba(255,255,255,0.06);
          background: rgba(255,255,255,0.02);
          cursor: pointer;
          text-align: left;
          transition: all 0.2s ease;
          width: 100%;
        }

        .sec-btn:hover {
          background: rgba(255,255,255,0.04);
          border-color: rgba(255,255,255,0.1);
        }

        .sec-btn.danger {
          border-color: rgba(239,68,68,0.15);
        }

        .sec-btn.danger:hover {
          background: rgba(239,68,68,0.04);
          border-color: rgba(239,68,68,0.3);
        }

        .sec-icon {
          width: 36px; height: 36px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .sec-text-title {
          font-size: 0.875rem;
          font-weight: 600;
          color: rgba(255,255,255,0.8);
          margin-bottom: 2px;
        }

        .sec-text-sub {
          font-size: 0.76rem;
          color: rgba(255,255,255,0.3);
        }

        .sec-btn.danger .sec-text-title { color: rgba(239,68,68,0.8); }

        /* Full-width security section */
        .prof-security {
          background: rgba(255,255,255,0.06);
          height: 1.5px;
          margin: 0;
        }

        .prof-security-card {
          background: #0d0f16;
          padding: 3rem;
          grid-column: 1 / -1;
        }

        @media (max-width: 768px) {
          .prof-root { padding: 1.5rem; }
          .prof-layout { grid-template-columns: 1fr; }
          .prof-main { padding: 2rem 1.5rem; }
        }
      `}</style>

      <div className={`prof-root ${mounted ? "mounted" : ""}`}>
        <div
          style={{
            maxWidth: 1000,
            margin: "0 auto 2rem",
            opacity: mounted ? 1 : 0,
            transform: mounted ? "none" : "translateY(12px)",
            transition: "all 0.5s ease",
          }}
        >
          <div
            style={{
              fontSize: "0.72rem",
              fontWeight: 600,
              color: "#00d4b4",
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              marginBottom: "0.4rem",
              display: "flex",
              alignItems: "center",
              gap: 8,
            }}
          >
            <span
              style={{
                width: 16,
                height: 1,
                background: "#00d4b4",
                display: "block",
              }}
            />
            Account
          </div>
          <h1
            style={{
              fontFamily: "'Syne', sans-serif",
              fontSize: "clamp(1.8rem, 3vw, 2.5rem)",
              fontWeight: 800,
              letterSpacing: "-0.03em",
              margin: 0,
              color: "white",
            }}
          >
            Profile Settings
          </h1>
        </div>

        <div className="prof-layout">
          {/* Sidebar */}
          <div className="prof-sidebar">
            <div className="prof-avatar-wrap">
              <div className="prof-avatar-ring" />
              <div className="prof-avatar">
                {(user.name || user.email || "U")[0].toUpperCase()}
              </div>
            </div>

            <div className="prof-user-name">{user.name || "User"}</div>
            <div className="prof-user-email">{user.email}</div>

            <div
              className={`prof-badge ${user.emailVerified ? "verified" : "pending"}`}
            >
              {user.emailVerified ? "✓ Verified" : "⚠ Pending"}
            </div>

            <div className="prof-meta">
              <div className="prof-meta-row">
                <span className="meta-key">Member since</span>
                <span className="meta-val">
                  {new Date(user.createdAt).toLocaleDateString("en-US", {
                    month: "short",
                    year: "numeric",
                  })}
                </span>
              </div>
              <div className="prof-meta-row">
                <span className="meta-key">Plan</span>
                <span className="meta-val" style={{ color: "#00d4b4" }}>
                  Pro
                </span>
              </div>
              <div className="prof-meta-row">
                <span className="meta-key">Status</span>
                <span className="meta-val" style={{ color: "#22c55e" }}>
                  Active
                </span>
              </div>
            </div>
          </div>

          {/* Main form */}
          <div className="prof-main">
            <div className="section-eyebrow">Personal info</div>
            <h2 className="section-title">Edit your profile</h2>

            <form onSubmit={handleSubmit}>
              <div className="field">
                <label className="field-label">Full name</label>
                <input
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  className="field-input"
                  placeholder="Your full name"
                />
              </div>

              <div className="field">
                <label className="field-label">Email address</label>
                <input
                  name="email"
                  value={form.email}
                  disabled
                  className="field-input"
                />
                <p className="field-hint">
                  Email cannot be changed for security reasons.
                </p>
              </div>

              <div style={{ display: "flex", justifyContent: "flex-end" }}>
                <button type="submit" disabled={isLoading} className="save-btn">
                  <Save size={15} />
                  {isLoading ? "Saving…" : "Save changes"}
                </button>
              </div>
            </form>

            <div className="form-divider" />

            <div className="section-eyebrow">Security</div>
            <div className="security-grid">
              <button className="sec-btn">
                <div
                  className="sec-icon"
                  style={{ background: "rgba(0,153,255,0.08)" }}
                >
                  <Lock size={16} color="#0099ff" />
                </div>
                <div>
                  <div className="sec-text-title">Change Password</div>
                  <div className="sec-text-sub">
                    Update your password to keep your account secure
                  </div>
                </div>
              </button>

              <button className="sec-btn">
                <div
                  className="sec-icon"
                  style={{ background: "rgba(168,85,247,0.08)" }}
                >
                  <Shield size={16} color="#a855f7" />
                </div>
                <div>
                  <div className="sec-text-title">
                    Two-Factor Authentication
                  </div>
                  <div className="sec-text-sub">
                    Add an extra layer of protection to your account
                  </div>
                </div>
              </button>

              <button className="sec-btn danger">
                <div
                  className="sec-icon"
                  style={{ background: "rgba(239,68,68,0.08)" }}
                >
                  <LogOut size={16} color="#ef4444" />
                </div>
                <div>
                  <div className="sec-text-title">Sign out all devices</div>
                  <div className="sec-text-sub">
                    End all active sessions on every device
                  </div>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
