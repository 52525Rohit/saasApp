import React, { useEffect, useState } from "react";
import {
  Users,
  TrendingUp,
  Activity,
  Settings,
  CreditCard,
  BarChart3,
  Award,
  User,
} from "lucide-react";
import useAuthStore from "../context/authStore";

export default function DashboardPage() {
  const { user, fetchUser } = useAuthStore();
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeSubscriptions: 0,
    revenue: 0,
  });
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    fetchUser();
    setStats({ totalUsers: 1250, activeSubscriptions: 890, revenue: 45230 });
    setTimeout(() => setMounted(true), 50);
  }, [fetchUser]);

  if (!user) {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "#08090d",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div
          style={{
            width: 40,
            height: 40,
            border: "2px solid rgba(0,212,180,0.2)",
            borderTop: "2px solid #00d4b4",
            borderRadius: "50%",
            animation: "spin 0.8s linear infinite",
          }}
        />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');

        .db-root {
          min-height: 100vh;
          background: #08090d;
          color: white;
          font-family: 'DM Sans', sans-serif;
          padding: 2.5rem;
        }

        .db-header {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          margin-bottom: 3rem;
          gap: 2rem;
          flex-wrap: wrap;
          opacity: 0;
          transform: translateY(16px);
          transition: all 0.6s ease;
        }

        .db-root.mounted .db-header { opacity: 1; transform: translateY(0); }

        .db-greeting {
          font-size: 0.75rem;
          font-weight: 600;
          color: #00d4b4;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          margin-bottom: 0.5rem;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .db-greeting::before {
          content: '';
          width: 20px;
          height: 1px;
          background: #00d4b4;
        }

        .db-name {
          font-family: 'Syne', sans-serif;
          font-size: clamp(1.8rem, 3vw, 2.8rem);
          font-weight: 800;
          letter-spacing: -0.03em;
          margin: 0 0 0.5rem;
        }

        .db-sub {
          color: rgba(255,255,255,0.35);
          font-size: 0.9rem;
          font-weight: 300;
        }

        .db-avatar {
          width: 56px; height: 56px;
          border-radius: 16px;
          background: linear-gradient(135deg, #00d4b4, #0099ff);
          display: flex;
          align-items: center;
          justify-content: center;
          font-family: 'Syne', sans-serif;
          font-weight: 800;
          font-size: 1.5rem;
          color: #08090d;
          flex-shrink: 0;
        }

        /* Stats row */
        .stat-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 1.5px;
          background: rgba(255,255,255,0.06);
          border-radius: 20px;
          overflow: hidden;
          margin-bottom: 2rem;
          opacity: 0;
          transform: translateY(16px);
          transition: all 0.6s ease 0.1s;
        }

        .db-root.mounted .stat-grid { opacity: 1; transform: translateY(0); }

        .stat-card {
          background: #0d0f16;
          padding: 2rem 2.5rem;
          position: relative;
          overflow: hidden;
          transition: background 0.3s;
        }

        .stat-card:hover { background: #111420; }

        .stat-card::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 1px;
          background: var(--accent);
          opacity: 0;
          transition: opacity 0.3s;
        }

        .stat-card:hover::before { opacity: 0.6; }

        .stat-label {
          font-size: 0.75rem;
          font-weight: 600;
          color: rgba(255,255,255,0.35);
          letter-spacing: 0.08em;
          text-transform: uppercase;
          margin-bottom: 1rem;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .stat-icon {
          width: 28px; height: 28px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--accent-bg);
        }

        .stat-value {
          font-family: 'Syne', sans-serif;
          font-size: clamp(2rem, 3vw, 2.8rem);
          font-weight: 800;
          letter-spacing: -0.03em;
          margin-bottom: 0.75rem;
        }

        .stat-change {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          font-size: 0.78rem;
          font-weight: 600;
          color: #22c55e;
          padding: 3px 10px;
          border-radius: 100px;
          background: rgba(34, 197, 94, 0.1);
        }

        .stat-progress {
          margin-top: 1.25rem;
          height: 2px;
          background: rgba(255,255,255,0.06);
          border-radius: 2px;
          overflow: hidden;
        }

        .stat-prog-fill {
          height: 100%;
          border-radius: 2px;
          background: var(--accent);
          transition: width 1s ease;
        }

        /* Section rows */
        .db-row {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 1.5px;
          background: rgba(255,255,255,0.06);
          border-radius: 20px;
          overflow: hidden;
          margin-bottom: 2rem;
          opacity: 0;
          transform: translateY(16px);
          transition: all 0.6s ease;
        }

        .db-root.mounted .db-row { opacity: 1; transform: translateY(0); }
        .db-root.mounted .db-row:nth-child(3) { transition-delay: 0.2s; }
        .db-root.mounted .db-row:nth-child(4) { transition-delay: 0.3s; }

        .db-card {
          background: #0d0f16;
          padding: 2rem 2.5rem;
        }

        .db-card.full { grid-column: 1 / -1; }

        .card-title {
          font-family: 'Syne', sans-serif;
          font-size: 1rem;
          font-weight: 700;
          letter-spacing: -0.01em;
          margin-bottom: 1.5rem;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .card-title span {
          font-family: 'DM Sans', sans-serif;
          font-size: 0.75rem;
          font-weight: 500;
          color: rgba(0,212,180,0.7);
          cursor: pointer;
          letter-spacing: 0;
        }

        /* Quick actions */
        .actions-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 12px;
        }

        .action-btn {
          padding: 1rem;
          border-radius: 12px;
          border: 1px solid rgba(255,255,255,0.06);
          background: rgba(255,255,255,0.02);
          cursor: pointer;
          transition: all 0.25s ease;
          text-align: left;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .action-btn:hover {
          background: rgba(255,255,255,0.05);
          border-color: rgba(255,255,255,0.12);
          transform: translateY(-2px);
        }

        .action-icon {
          width: 36px; height: 36px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .action-label {
          font-size: 0.82rem;
          font-weight: 600;
          color: rgba(255,255,255,0.7);
        }

        /* Activity list */
        .activity-list { display: flex; flex-direction: column; gap: 4px; }

        .activity-item {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 12px 10px;
          border-radius: 10px;
          transition: background 0.2s;
          cursor: pointer;
        }

        .activity-item:hover { background: rgba(255,255,255,0.03); }

        .activity-dot {
          width: 36px; height: 36px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .activity-text { flex: 1; }

        .activity-label {
          font-size: 0.875rem;
          font-weight: 500;
          color: rgba(255,255,255,0.8);
          margin-bottom: 2px;
        }

        .activity-time {
          font-size: 0.75rem;
          color: rgba(255,255,255,0.3);
        }

        .activity-arrow {
          color: rgba(255,255,255,0.15);
          font-size: 0.8rem;
          transition: all 0.2s;
        }

        .activity-item:hover .activity-arrow {
          color: rgba(255,255,255,0.4);
          transform: translateX(2px);
        }

        /* Performance metrics */
        .metric-row {
          margin-bottom: 1.5rem;
        }

        .metric-header {
          display: flex;
          justify-content: space-between;
          margin-bottom: 8px;
          font-size: 0.85rem;
        }

        .metric-name { color: rgba(255,255,255,0.6); }
        .metric-val { font-weight: 600; color: white; }

        .metric-bar {
          height: 4px;
          background: rgba(255,255,255,0.06);
          border-radius: 4px;
          overflow: hidden;
        }

        .metric-fill {
          height: 100%;
          border-radius: 4px;
          transition: width 1.2s ease;
        }

        /* Events */
        .event-item {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          padding: 12px 0;
          border-bottom: 1px solid rgba(255,255,255,0.04);
        }

        .event-item:last-child { border-bottom: none; }

        .event-line {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          flex-shrink: 0;
        }

        .event-dot {
          width: 8px; height: 8px;
          border-radius: 50%;
          background: #00d4b4;
          margin-top: 5px;
        }

        .event-vline {
          width: 1px;
          flex: 1;
          background: rgba(255,255,255,0.08);
          min-height: 24px;
        }

        .event-label {
          font-size: 0.875rem;
          font-weight: 500;
          color: rgba(255,255,255,0.8);
          margin-bottom: 3px;
        }

        .event-time {
          font-size: 0.75rem;
          color: rgba(255,255,255,0.3);
        }

        @keyframes spin { to { transform: rotate(360deg); } }

        @media (max-width: 900px) {
          .db-root { padding: 1.5rem; }
          .stat-grid, .db-row { grid-template-columns: 1fr; }
          .actions-grid { grid-template-columns: repeat(2, 1fr); }
        }
      `}</style>

      <div className={`db-root ${mounted ? "mounted" : ""}`}>
        {/* Header */}
        <div className="db-header">
          <div>
            <div className="db-greeting">Dashboard</div>
            <h1 className="db-name">
              Welcome back, {user.name?.split(" ")[0] || "there"}
            </h1>
            <p className="db-sub">
              Here's what's happening with your workspace today.
            </p>
          </div>
          <div className="db-avatar">
            {(user.name || user.email || "U")[0].toUpperCase()}
          </div>
        </div>

        {/* Stats */}
        <div className="stat-grid">
          {[
            {
              icon: Users,
              label: "Total Users",
              value: "1,250",
              change: "+12.5%",
              accent: "#00d4b4",
              accBg: "rgba(0,212,180,0.08)",
              prog: 75,
            },
            {
              icon: Activity,
              label: "Active Subscriptions",
              value: "890",
              change: "+8.2%",
              accent: "#0099ff",
              accBg: "rgba(0,153,255,0.08)",
              prog: 60,
            },
            {
              icon: TrendingUp,
              label: "Revenue",
              value: "$45,230",
              change: "+24.3%",
              accent: "#a855f7",
              accBg: "rgba(168,85,247,0.08)",
              prog: 85,
            },
          ].map((s) => {
            const Icon = s.icon;
            return (
              <div
                className="stat-card"
                key={s.label}
                style={{ "--accent": s.accent, "--accent-bg": s.accBg }}
              >
                <div className="stat-label">
                  <div className="stat-icon" style={{ background: s.accBg }}>
                    <Icon size={14} color={s.accent} />
                  </div>
                  {s.label}
                </div>
                <div className="stat-value">{s.value}</div>
                <div className="stat-change">↑ {s.change}</div>
                <div className="stat-progress">
                  <div
                    className="stat-prog-fill"
                    style={{ width: `${s.prog}%`, background: s.accent }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Quick actions + activity */}
        <div className="db-row">
          <div className="db-card">
            <div className="card-title">Quick Actions</div>
            <div className="actions-grid">
              {[
                {
                  icon: Settings,
                  label: "Settings",
                  bg: "rgba(0,153,255,0.1)",
                  color: "#0099ff",
                },
                {
                  icon: CreditCard,
                  label: "Billing",
                  bg: "rgba(0,212,180,0.1)",
                  color: "#00d4b4",
                },
                {
                  icon: Users,
                  label: "Team",
                  bg: "rgba(168,85,247,0.1)",
                  color: "#a855f7",
                },
                {
                  icon: BarChart3,
                  label: "Analytics",
                  bg: "rgba(245,158,11,0.1)",
                  color: "#f59e0b",
                },
              ].map((a) => {
                const Icon = a.icon;
                return (
                  <button className="action-btn" key={a.label}>
                    <div className="action-icon" style={{ background: a.bg }}>
                      <Icon size={16} color={a.color} />
                    </div>
                    <span className="action-label">{a.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="db-card">
            <div className="card-title">
              Recent Activity
              <span>View all</span>
            </div>
            <div className="activity-list">
              {[
                {
                  icon: User,
                  label: "New user registered",
                  time: "2 hours ago",
                  bg: "rgba(0,212,180,0.1)",
                  color: "#00d4b4",
                },
                {
                  icon: CreditCard,
                  label: "New subscription created",
                  time: "5 hours ago",
                  bg: "rgba(0,153,255,0.1)",
                  color: "#0099ff",
                },
                {
                  icon: Award,
                  label: "Milestone: 1,000 users",
                  time: "1 day ago",
                  bg: "rgba(168,85,247,0.1)",
                  color: "#a855f7",
                },
                {
                  icon: TrendingUp,
                  label: "Revenue up 20%",
                  time: "2 days ago",
                  bg: "rgba(245,158,11,0.1)",
                  color: "#f59e0b",
                },
              ].map((a) => {
                const Icon = a.icon;
                return (
                  <div className="activity-item" key={a.label}>
                    <div className="activity-dot" style={{ background: a.bg }}>
                      <Icon size={14} color={a.color} />
                    </div>
                    <div className="activity-text">
                      <div className="activity-label">{a.label}</div>
                      <div className="activity-time">{a.time}</div>
                    </div>
                    <span className="activity-arrow">→</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Performance + Events */}
        <div className="db-row">
          <div className="db-card">
            <div className="card-title">Performance</div>
            {[
              {
                name: "Conversion Rate",
                val: "3.2%",
                prog: 32,
                color: "#00d4b4",
              },
              {
                name: "User Retention",
                val: "87.5%",
                prog: 87,
                color: "#0099ff",
              },
              {
                name: "System Uptime",
                val: "99.9%",
                prog: 99,
                color: "#a855f7",
              },
            ].map((m) => (
              <div className="metric-row" key={m.name}>
                <div className="metric-header">
                  <span className="metric-name">{m.name}</span>
                  <span className="metric-val">{m.val}</span>
                </div>
                <div className="metric-bar">
                  <div
                    className="metric-fill"
                    style={{ width: `${m.prog}%`, background: m.color }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="db-card">
            <div className="card-title">Upcoming</div>
            {[
              { label: "Team Meeting", time: "Today at 2:00 PM" },
              { label: "System Maintenance", time: "Tomorrow at 3:00 AM" },
              { label: "Product Launch", time: "Next Monday" },
            ].map((e, i, arr) => (
              <div className="event-item" key={e.label}>
                <div className="event-line">
                  <div className="event-dot" />
                  {i < arr.length - 1 && <div className="event-vline" />}
                </div>
                <div>
                  <div className="event-label">{e.label}</div>
                  <div className="event-time">{e.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
