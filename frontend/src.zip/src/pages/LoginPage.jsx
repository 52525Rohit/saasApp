import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";
import toast from "react-hot-toast";
import useAuthStore from "../context/authStore";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api/v1";

export default function LoginPage() {
  const navigate = useNavigate();
  const { login, isLoading } = useAuthStore();
  const [form, setForm] = useState({ email: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await login(form.email, form.password);
    if (result.success) {
      toast.success("Welcome back!");
      navigate("/dashboard");
    } else {
      toast.error(result.message || "Login failed");
    }
  };

  const handleOAuth = (provider) => {
    window.location.href = `${API_URL}/auth/${provider}`;
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&display=swap');

        .login-page {
          min-height: 100vh;
          background: #08090d;
          display: grid;
          grid-template-columns: 1fr 1fr;
          font-family: 'DM Sans', sans-serif;
          color: white;
        }

        /* Left panel — decorative */
        .login-left {
          background: linear-gradient(135deg, #0d0f16 0%, #0a1628 100%);
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          padding: 3rem;
          position: relative;
          overflow: hidden;
          border-right: 1px solid rgba(255,255,255,0.06);
        }

        .ll-orb {
          position: absolute;
          border-radius: 50%;
          filter: blur(60px);
          opacity: 0.2;
          pointer-events: none;
        }

        .ll-orb-1 {
          width: 400px; height: 400px;
          background: radial-gradient(circle, #00d4b4, transparent);
          top: -100px; left: -100px;
        }

        .ll-orb-2 {
          width: 300px; height: 300px;
          background: radial-gradient(circle, #0099ff, transparent);
          bottom: 100px; right: -50px;
        }

        .ll-grid {
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255,255,255,0.025) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.025) 1px, transparent 1px);
          background-size: 40px 40px;
        }

        .ll-brand {
          position: relative;
          z-index: 2;
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .ll-logo {
          width: 36px; height: 36px;
          border-radius: 10px;
          background: linear-gradient(135deg, #00d4b4, #0099ff);
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .ll-diamond {
          width: 13px; height: 13px;
          background: #08090d;
          transform: rotate(45deg);
          border-radius: 2px;
        }

        .ll-name {
          font-family: 'Syne', sans-serif;
          font-weight: 800;
          font-size: 1.2rem;
          letter-spacing: -0.02em;
        }

        .ll-center {
          position: relative;
          z-index: 2;
        }

        .ll-quote {
          font-family: 'Syne', sans-serif;
          font-size: clamp(1.6rem, 2.8vw, 2.5rem);
          font-weight: 700;
          letter-spacing: -0.03em;
          line-height: 1.2;
          margin-bottom: 1.5rem;
        }

        .ll-quote em {
          font-style: normal;
          background: linear-gradient(135deg, #00d4b4, #0099ff);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .ll-testimonial {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 1rem 1.25rem;
          border-radius: 12px;
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(255,255,255,0.07);
          backdrop-filter: blur(10px);
        }

        .ll-avatar {
          width: 40px; height: 40px;
          border-radius: 50%;
          background: linear-gradient(135deg, #a855f7, #ec4899);
          display: flex;
          align-items: center;
          justify-content: center;
          font-family: 'Syne', sans-serif;
          font-weight: 700;
          font-size: 1rem;
          color: white;
          flex-shrink: 0;
        }

        .ll-person-name {
          font-weight: 600;
          font-size: 0.875rem;
        }

        .ll-person-role {
          font-size: 0.75rem;
          color: rgba(255,255,255,0.4);
        }

        .ll-bottom {
          position: relative;
          z-index: 2;
          display: flex;
          gap: 1.5rem;
        }

        .ll-stat .s-val {
          font-family: 'Syne', sans-serif;
          font-size: 1.6rem;
          font-weight: 800;
          letter-spacing: -0.03em;
          background: linear-gradient(135deg, white, rgba(255,255,255,0.5));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .ll-stat .s-lbl {
          font-size: 0.75rem;
          color: rgba(255,255,255,0.35);
          text-transform: uppercase;
          letter-spacing: 0.08em;
        }

        /* Right panel — form */
        .login-right {
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 3rem 2rem;
          background: #08090d;
        }

        .login-form-wrap {
          width: 100%;
          max-width: 420px;
          animation: fadeUp 0.6s ease both;
        }

        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .form-eyebrow {
          font-size: 0.75rem;
          font-weight: 600;
          color: #00d4b4;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          margin-bottom: 0.75rem;
        }

        .form-title {
          font-family: 'Syne', sans-serif;
          font-size: 2.2rem;
          font-weight: 800;
          letter-spacing: -0.03em;
          margin: 0 0 0.5rem;
        }

        .form-sub {
          color: rgba(255,255,255,0.4);
          font-size: 0.9rem;
          margin-bottom: 2.5rem;
        }

        .form-sub a {
          color: #00d4b4;
          text-decoration: none;
          font-weight: 500;
        }

        .form-sub a:hover { text-decoration: underline; }

        /* OAuth */
        .oauth-group {
          display: flex;
          flex-direction: column;
          gap: 10px;
          margin-bottom: 1.75rem;
        }

        .oauth-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          width: 100%;
          padding: 11px 16px;
          border-radius: 10px;
          border: 1px solid rgba(255,255,255,0.1);
          background: rgba(255,255,255,0.03);
          color: rgba(255,255,255,0.8);
          font-family: 'DM Sans', sans-serif;
          font-size: 0.875rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .oauth-btn:hover {
          background: rgba(255,255,255,0.07);
          border-color: rgba(255,255,255,0.2);
          color: white;
        }

        .divider {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 1.75rem;
        }

        .divider-line {
          flex: 1;
          height: 1px;
          background: rgba(255,255,255,0.08);
        }

        .divider-text {
          font-size: 0.75rem;
          color: rgba(255,255,255,0.3);
          white-space: nowrap;
        }

        /* Fields */
        .field {
          margin-bottom: 1.25rem;
        }

        .field-label {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 0.5rem;
          font-size: 0.8rem;
          font-weight: 600;
          color: rgba(255,255,255,0.6);
          letter-spacing: 0.04em;
          text-transform: uppercase;
        }

        .field-label a {
          color: rgba(0,212,180,0.7);
          text-decoration: none;
          font-size: 0.75rem;
          letter-spacing: 0;
          text-transform: none;
          font-weight: 400;
        }

        .field-label a:hover { color: #00d4b4; }

        .field-input-wrap {
          position: relative;
        }

        .field-input {
          width: 100%;
          padding: 12px 16px;
          border-radius: 10px;
          border: 1px solid rgba(255,255,255,0.08);
          background: rgba(255,255,255,0.04);
          color: white;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.9rem;
          outline: none;
          transition: all 0.2s ease;
        }

        .field-input::placeholder { color: rgba(255,255,255,0.2); }

        .field-input:focus {
          border-color: rgba(0,212,180,0.4);
          background: rgba(0,212,180,0.03);
          box-shadow: 0 0 0 3px rgba(0,212,180,0.06);
        }

        .field-input.has-toggle { padding-right: 44px; }

        .toggle-btn {
          position: absolute;
          right: 12px;
          top: 50%;
          transform: translateY(-50%);
          background: none;
          border: none;
          cursor: pointer;
          color: rgba(255,255,255,0.3);
          padding: 4px;
          transition: color 0.2s;
        }

        .toggle-btn:hover { color: rgba(255,255,255,0.7); }

        .submit-btn {
          width: 100%;
          padding: 13px 20px;
          border-radius: 10px;
          border: none;
          background: linear-gradient(135deg, #00d4b4, #0099ff);
          color: #08090d;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.95rem;
          font-weight: 700;
          cursor: pointer;
          letter-spacing: 0.02em;
          transition: all 0.25s ease;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          margin-top: 1.75rem;
          position: relative;
          overflow: hidden;
        }

        .submit-btn::before {
          content: '';
          position: absolute;
          inset: 0;
          background: rgba(255,255,255,0.2);
          opacity: 0;
          transition: opacity 0.2s;
        }

        .submit-btn:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 12px 30px rgba(0,212,180,0.3);
        }

        .submit-btn:hover::before { opacity: 1; }
        .submit-btn:disabled { opacity: 0.6; cursor: not-allowed; }

        .spinner {
          width: 16px; height: 16px;
          border: 2px solid rgba(8,9,13,0.3);
          border-top-color: #08090d;
          border-radius: 50%;
          animation: spin 0.7s linear infinite;
        }

        @keyframes spin { to { transform: rotate(360deg); } }

        @media (max-width: 768px) {
          .login-page { grid-template-columns: 1fr; }
          .login-left { display: none; }
        }
      `}</style>

      <div className="login-page">
        {/* Left decorative panel */}
        <div className="login-left">
          <div className="ll-orb ll-orb-1" />
          <div className="ll-orb ll-orb-2" />
          <div className="ll-grid" />

          <div className="ll-brand">
            <div className="ll-logo">
              <div className="ll-diamond" />
            </div>
            <span className="ll-name">ApexSaaS</span>
          </div>

          <div className="ll-center">
            <div className="ll-quote">
              The modern stack for
              <br />
              <em>ambitious teams.</em>
            </div>
            <div className="ll-testimonial">
              <div className="ll-avatar">S</div>
              <div>
                <div className="ll-person-name">Sarah Chen, CPO</div>
                <div className="ll-person-role">
                  Scaled us from 0 to 200k users
                </div>
              </div>
            </div>
          </div>

          <div className="ll-bottom">
            {[
              { v: "40K+", l: "Teams" },
              { v: "99.99%", l: "Uptime" },
              { v: "SOC2", l: "Certified" },
            ].map((s) => (
              <div className="ll-stat" key={s.l}>
                <div className="s-val">{s.v}</div>
                <div className="s-lbl">{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right form panel */}
        <div className="login-right">
          <div className="login-form-wrap">
            <div className="form-eyebrow">Welcome back</div>
            <h1 className="form-title">Sign in</h1>
            <p className="form-sub">
              New here? <Link to="/register">Create a free account →</Link>
            </p>

            {/* OAuth */}
            <div className="oauth-group">
              <button
                className="oauth-btn"
                onClick={() => handleOAuth("google")}
              >
                <svg width="18" height="18" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  />
                </svg>
                Continue with Google
              </button>
              <button
                className="oauth-btn"
                onClick={() => handleOAuth("github")}
              >
                <svg
                  width="18"
                  height="18"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.17 6.839 9.49.5.092.682-.217.682-.482 0-.237-.008-.866-.013-1.7-2.782.604-3.369-1.34-3.369-1.34-.454-1.156-1.11-1.464-1.11-1.464-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.564 9.564 0 0112 6.836c.85.004 1.705.115 2.504.337 1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.202 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48C19.138 20.167 22 16.418 22 12c0-5.523-4.477-10-10-10z" />
                </svg>
                Continue with GitHub
              </button>
            </div>

            <div className="divider">
              <div className="divider-line" />
              <span className="divider-text">or continue with email</span>
              <div className="divider-line" />
            </div>

            <form onSubmit={handleSubmit}>
              <div className="field">
                <label className="field-label">Email address</label>
                <div className="field-input-wrap">
                  <input
                    type="email"
                    name="email"
                    value={form.email}
                    onChange={handleChange}
                    required
                    placeholder="you@example.com"
                    className="field-input"
                  />
                </div>
              </div>

              <div className="field">
                <label className="field-label">
                  Password
                  <Link to="/forgot-password">Forgot password?</Link>
                </label>
                <div className="field-input-wrap">
                  <input
                    type={showPassword ? "text" : "password"}
                    name="password"
                    value={form.password}
                    onChange={handleChange}
                    required
                    placeholder="••••••••"
                    className="field-input has-toggle"
                  />
                  <button
                    type="button"
                    className="toggle-btn"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <button type="submit" disabled={isLoading} className="submit-btn">
                {isLoading ? (
                  <>
                    <div className="spinner" /> Signing in…
                  </>
                ) : (
                  "Sign in →"
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}
